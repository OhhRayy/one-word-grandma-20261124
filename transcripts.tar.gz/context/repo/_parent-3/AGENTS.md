# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Lessons
- `~/workspace/chipart404/search.c` keccak-nya RUSAK (konstanta ronde ke-24 hilang + ada bug lain yang belum ketemu; hash-nya tidak cocok dengan pycryptodome untuk input yang sama) — pencarian Chip404 itu tidak pernah bisa menemukan nonce yang valid. Jangan pakai search.c itu; untuk PoW pakai pencarian Python + pycryptodome (`~/workspace/pawgang/search_py.py`, multiprocessing 4 worker, ~140k hash/detik per worker, verifikasi nonce dengan dry-call `mint(nonce)` on-chain sebelum preview). Nonce Paw Gang yang lolos: hash harus punya ≥ difficultyBits leading zero bits (byte string, bit pertama = MSB byte 0).
- Padding token id untuk eth_call: token id hex harus total 64 karakter. Contoh token 1615 = 0x64f → `"0"*61 + "64f"`; token 4357 = 0x1105 → `"0"*60 + "1105"`. Pad yang salah bikin ownerOf mengembalikan alamat hantu/phantom.
- `baw` sering hilang setelah pergantian VM — reinstall `npm install -g @binance/agentic-wallet@1.12.0`, lalu cek `baw wallet status`; dalam banyak kasus sesi masih login (ALREADY_CONNECTED), tapi kadang perlu QR baru.
